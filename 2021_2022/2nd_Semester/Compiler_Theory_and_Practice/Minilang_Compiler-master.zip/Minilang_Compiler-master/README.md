# Compilers

Assignment Project

Directory Structure:

CPS2000_Assignment_2019 : The assignment specification
CPS2000 Assignment Report - Daniel Cauchi : The report for the assignment
code : Folder containing the code and CMakeLists.txt to build the file and Linux executable
code/src : The code itself with its substructure
code/InputFiles : Example files used in the video showcase
code/CmakeLists.txt : use the "cmake ." command to generate the makefile and then use "make" to build the executable

Video showcase: https://www.youtube.com/watch?v=kv1VEmtuk6E