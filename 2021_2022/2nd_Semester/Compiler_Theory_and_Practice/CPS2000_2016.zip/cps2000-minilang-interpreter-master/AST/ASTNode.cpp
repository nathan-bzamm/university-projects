#include "ASTNode.h"

ASTNode::ASTNode(){}