#include <string>
#include "ASTLiteralExpressionNode.h"
#include "ASTRealLiteralExpressionNode.h"

ASTLiteralExpressionNode::ASTLiteralExpressionNode(){}
