#!/bin/bash

cd src
./main