#include "../../include/AST/ASTNode.h"

ASTNode::ASTNode() {}

