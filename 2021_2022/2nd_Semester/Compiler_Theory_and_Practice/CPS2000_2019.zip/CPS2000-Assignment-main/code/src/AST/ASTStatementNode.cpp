#include "../../include/AST/ASTStatementNode.h"

ASTStatementNode::ASTStatementNode() {}