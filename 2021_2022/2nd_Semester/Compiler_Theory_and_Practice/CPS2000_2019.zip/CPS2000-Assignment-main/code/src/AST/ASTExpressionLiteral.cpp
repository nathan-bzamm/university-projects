#include "../../include/AST/ASTExpressionLiteral.h"

//Literals
ASTExpressionLiteral::ASTExpressionLiteral() {}

