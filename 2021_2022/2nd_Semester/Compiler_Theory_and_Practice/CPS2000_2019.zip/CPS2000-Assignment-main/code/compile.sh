#!/bin/bash

g++ -std=c++11 -o src/main src/main.cpp

