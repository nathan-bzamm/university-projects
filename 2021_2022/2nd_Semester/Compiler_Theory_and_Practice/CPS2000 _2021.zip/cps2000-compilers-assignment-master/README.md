# CPS2000 - Compiler Theory and Practice Assignment 2019

In this assignment, a lexer, parser and interpreter were built to handle the MiniLang programming language. Its specification can be found in the **CPS2000_Assignment_Specification_2019.pdf** file. An overview of my implementation can be found in the **CPS2000 Assignment Report.pdf** file.