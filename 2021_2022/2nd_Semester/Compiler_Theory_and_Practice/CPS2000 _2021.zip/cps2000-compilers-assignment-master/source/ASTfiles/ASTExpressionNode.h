/*
 * Contains all the nodes that can be used in an expression
 */

